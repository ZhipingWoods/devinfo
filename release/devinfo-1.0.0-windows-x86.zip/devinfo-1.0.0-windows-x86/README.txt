devinfo 1.0.0 - one probe, the whole machine
==================================================

Platform: Windows 7 or newer, 32-bit (i686), also runs on 64-bit Windows
Files:    devinfo.exe, devinfo.dll

Run it
------
  ./devinfo                 table on a terminal, JSON when piped
  ./devinfo --table         force the table
  ./devinfo --json          force JSON
  ./devinfo --bench         add a real memory-bandwidth measurement
  ./devinfo --version

No installer and no runtime: it is one static binary. Nothing is written
anywhere except devinfo-report.txt / .json, and only when you double-click
it on Windows.

What it reports
---------------
CPU cores, caches, ISA extensions; GPU SM count, tensor cores, VRAM and
bandwidth; NPU throughput; PCIe link; installed stacks (CUDA, cuDNN,
TensorRT, CANN, ROCm); and what model sizes the machine can actually run.

Anything printed with a leading tilde (~) was derived from a chip spec
table, not read from the hardware. The JSON marks the same values in the
"estimated" array, so nothing is silently invented.

Plugin use
----------
A C ABI shared library ships alongside. It exports four symbols:

  uint32_t devinfo_abi_version(void);
  const char* devinfo_version(void);
  char* devinfo_probe_json(uint32_t flags);   /* 0 = fast, 1 = bench */
  void devinfo_free(char* p);

Full details: https://github.com/ZhipingWoods/devinfo
